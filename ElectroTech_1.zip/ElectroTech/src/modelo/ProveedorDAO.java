package modelo;

public class ProveedorDAO {

	public ProveedorDAO() {
		// TODO Auto-generated constructor stub
	}

}
