package modelo;

public class Proveedor {

	public Proveedor() {
		// TODO Auto-generated constructor stub
	}

}
