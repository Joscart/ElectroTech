package modelo;

public class Estadistica {

	public Estadistica() {
		// TODO Auto-generated constructor stub
	}

}
