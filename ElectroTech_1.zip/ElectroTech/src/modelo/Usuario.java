package modelo;

public class Usuario {

	public Usuario() {
		// TODO Auto-generated constructor stub
	}

}
