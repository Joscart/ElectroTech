package modelo;

public class Producto {

	public Producto() {
		// TODO Auto-generated constructor stub
	}

}
