package modelo;

public class ProductoDAO {

	public ProductoDAO() {
		// TODO Auto-generated constructor stub
	}

}
