package controlador;

import vista.*;

public class logic_ProveedorGS {
	
	private ProveedorGS lb;

	public logic_ProveedorGS(ProveedorGS lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
