package controlador;

import vista.*;

public class logic_ProductoGS {
	
	private ProductoGS lb;

	public logic_ProductoGS(ProductoGS lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
