package controlador;

import vista.*;

public class logic_Menu {

	private Menu lb;
	
	public logic_Menu(Menu lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
