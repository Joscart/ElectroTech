package controlador;

import vista.*;

public class logic_Informacion {
	
	private Informacion lb;

	public logic_Informacion(Informacion lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
