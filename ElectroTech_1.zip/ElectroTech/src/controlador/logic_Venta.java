package controlador;

import vista.*;

public class logic_Venta {
	
	private Venta lb;

	public logic_Venta(Venta lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
