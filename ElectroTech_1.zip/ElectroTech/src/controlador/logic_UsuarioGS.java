package controlador;

import vista.*;

public class logic_UsuarioGS {
	
	private UsuarioGS lb;

	public logic_UsuarioGS(UsuarioGS lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
