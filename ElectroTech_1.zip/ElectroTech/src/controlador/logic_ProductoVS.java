package controlador;

import vista.*;

public class logic_ProductoVS {
	
	private ProductoVS lb;

	public logic_ProductoVS(ProductoVS lb) {
		// TODO Auto-generated constructor stub
		this.lb = lb;
	}

}
